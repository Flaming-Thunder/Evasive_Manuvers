#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform DamageConfig {
    float InFrequency;
    float InMin;
    float InMax;
    float InDist;
};

layout(location = 0) out vec4 fragColor;

void main(){

    float a = 0.5*(InMax-InMin)*sin(GameTime*InFrequency*2400.0) + 0.5*(InMax+InMin);

    a = clamp(a*length(texCoord - 0.5)-0.5*InDist,0.0,1.0);

    vec4 vignetteColor = vec4(1.0,0.0,0.0,1.0);
    vec4 color = texture(InSampler,texCoord);

    fragColor = mix(color,vignetteColor,a);
}