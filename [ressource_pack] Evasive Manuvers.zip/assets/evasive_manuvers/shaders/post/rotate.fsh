#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform RotScaleConfig {
    vec2 InScale;
    vec2 InOffset;
    float InRotation;
};

layout(location = 0) out vec4 fragColor;

void main(){

    float a = InRotation*0.0174532925;

    mat2 rot = mat2(
        cos(a), -sin(a),
        sin(a),  cos(a)
    );

    vec2 uv = rot * (texCoord - 0.5);
    uv = vec2(uv.x/InScale.x,uv.y/InScale.y) + 0.5;

    vec4 color = texture(InSampler,uv);
    fragColor = vec4(color.rgb,1.0);
}